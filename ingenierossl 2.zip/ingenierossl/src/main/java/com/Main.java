package com;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author angelalonsosanchez
 */
import java.sql.Connection;

public class Main {

    public static void main(String[] args) {
	//write your code here
        Connection datos =  DbUtil.getConnection();
        User usuario = new User("12345623", "Pedro", "Gutiérrez", "juan.gutierrez@gmail.com", "juanito123", "Clientes", 981729763);
        UserDao dao = new UserDao();
        dao.addUser(usuario);
        //dao.getAllUsers();

    }
}